import java.util.*;

public class AntiDopingPlatform {

    static Scanner sc = new Scanner(System.in);
    static Player player;

    static class Player {
        String name;
        int quizScore;
        int challengeScore;
        int scenarioScore;
        int totalScore;
        String badge;

        Player(String name) {
            this.name = name;
            this.quizScore = 0;
            this.challengeScore = 0;
            this.scenarioScore = 0;
            this.totalScore = 0;
            this.badge = "None";
        }

        void calculateTotalScore() {
            totalScore = quizScore + challengeScore + scenarioScore;
        }

        void updateBadge() {
            calculateTotalScore();
            if (totalScore >= 160) badge = "Gold";
            else if (totalScore >= 100) badge = "Silver";
            else if (totalScore >= 60) badge = "Bronze";
            else badge = "Participant";
        }
    }

    public static void main(String[] args) {
        System.out.println(" Welcome to the Anti-Doping Learning Platform");
        registerUser();

        learnModules();

        System.out.println("\nYou will now participate in all 3 Game Modes:");
        playQuizMode();
        playChallengeMode();
        playScenarioMode();

        player.updateBadge();
        showDashboard();
        showLeaderboard();
    }

    static void registerUser() {
        System.out.print("Enter your name to register/login: ");
        String name = sc.nextLine();
        player = new Player(name);
        System.out.println(" Hello " + name + "! You're successfully logged in.");
    }

    static void learnModules() {
        System.out.println("\n Learning Modules...");
        System.out.println(" Watching videos, reading cases...");
        pause();
        System.out.println(" Module Completed!");
    }

    static void playQuizMode() {
        System.out.println("\n=== QUIZ MODE ===");
        String[] questions = {
            "1. What does 'doping' refer to in sports?\n a) Healthy diet\n b) Using banned substances\n c) Exercise\n d) Energy drinks",
            "2. Who sets the list of prohibited substances?\n a) NADA\n b) FIFA\n c) WHO\n d) WADA",
            "3. What is the main goal of anti-doping rules?\n a) To scare athletes\n b) Ensure fair play\n c) Encourage shortcuts\n d) None of the above"
        };
        char[] answers = {'b', 'd', 'b'};

        player.quizScore = askQuestions(questions, answers);
        System.out.println(" You earned " + player.quizScore + " points in Quiz Mode.");
    }

    static void playChallengeMode() {
        System.out.println("\n=== CHALLENGE MODE ===");
        String[] questions = {
            "1. What should an athlete do if prescribed a prohibited substance?\n a) Ignore it\n b) Get a TUE (Therapeutic Use Exemption)\n c) Take it secretly\n d) Switch sports",
            "2. How long can a doping ban last?\n a) 1 day\n b) 1 week\n c) Several years or lifetime\n d) No ban at all",
            "3. What does NADA stand for?\n a) National Anti-Doping Agency\n b) National Athletic Drug Association\n c) National Agency for Drugs and Athletes\n d) None of the above"
        };
        char[] answers = {'b', 'c', 'a'};

        player.challengeScore = askQuestions(questions, answers);
        System.out.println(" You earned " + player.challengeScore + " points in Challenge Mode.");
    }

    static void playScenarioMode() {
        System.out.println("\n=== SCENARIO-BASED MODE ===");
        System.out.println(" You are analyzing anti-doping case scenarios...");
        pause();

        String[] scenarios = {
            "1. A top athlete suddenly improves performance drastically. What might be a cause?\n a) Training only\n b) Genetics\n c) Potential doping\n d) Motivation",
            "2. An athlete refuses to undergo testing. What's the likely outcome?\n a) Praise\n b) Penalty or ban\n c) Promotion\n d) Nothing happens"
        };
        char[] answers = {'c', 'b'};

        player.scenarioScore = askQuestions(scenarios, answers);
        System.out.println(" You earned " + player.scenarioScore + " points in Scenario Mode.");
    }

    static int askQuestions(String[] questions, char[] answers) {
        int score = 0;
        for (int i = 0; i < questions.length; i++) {
            System.out.println("\n" + questions[i]);
            System.out.print("Your answer: ");
            char userAnswer = sc.next().toLowerCase().charAt(0);
            if (userAnswer == answers[i]) {
                System.out.println(" Correct!");
                score += 20;
            } else {
                System.out.println(" Wrong! Correct answer: " + answers[i]);
            }
        }
        return score;
    }

    static void showDashboard() {
        System.out.println("\n=== DASHBOARD ===");
        System.out.println("Name: " + player.name);
        System.out.println("Quiz Score: " + player.quizScore);
        System.out.println("Challenge Score: " + player.challengeScore);
        System.out.println("Scenario Score: " + player.scenarioScore);
        System.out.println("Total Points: " + player.totalScore);
        System.out.println("Badge Earned: " + player.badge);
    }

    static void showLeaderboard() {
        System.out.println("\n=== LEADERBOARD (Sample Data) ===");
        System.out.println("1. Aditi - 180");
        System.out.println("2. " + player.name + " - " + player.totalScore);
        System.out.println("3. Rohan - 120");
        System.out.println("\nThanks for participating! Promote clean sport.");
    }

    static void pause() {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {}
    }
}